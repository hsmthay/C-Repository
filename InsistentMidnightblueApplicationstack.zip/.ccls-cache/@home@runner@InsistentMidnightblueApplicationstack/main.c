#include <stdio.h>

int main(void) {
  
  printf("Meu nome é Thayany\n");
  
  return 0;
}